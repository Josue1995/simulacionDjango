"""Cultivos URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import include, path
from apps.Ciclo_Cultivo import views
from django.contrib.auth.views import logout, password_reset, password_reset_done, password_reset_confirm, password_reset_complete

urlpatterns = [
    path('', include('apps.Ciclo_Cultivo.urls')),
    path('inicio', views.iniciarSesion, name = "sesion"),
    path('registarAdmin', views.registrarA.as_view(), name='admin'),
    path('login', views.log_in, name="login"),
    path('logout', logout, name = "logout"),
    path('simulacion', views.simulacion.as_view(), name = "simular"),
    path('editar', views.editarPerfil.as_view(), name="editar"),
    path('reestablecer/contrasenia', password_reset, {'template_name': 'registro/reset_password.html', 'email_template_name':'registro/password_email.html' }, name='reset'),
    path('reestablecer/confirmado', password_reset_done, {'template_name':'registro/password_sent.html'}, name='email_enviado'),
    path('reestablecer/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>.+)/', password_reset_confirm, {'template_name':'registro/password_confirm.html'}, name='res_con'),
    path('reestablecer/terminado', password_reset_complete, {'template_name':'registro/confirm_reset.html'}, name='fin'),
]
