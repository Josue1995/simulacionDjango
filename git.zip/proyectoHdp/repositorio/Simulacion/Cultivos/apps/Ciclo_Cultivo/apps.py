from django.apps import AppConfig


class CicloCultivoConfig(AppConfig):
    name = 'Ciclo_Cultivo'
