from django.db import models
from django.contrib.auth.models import User
import os
# Create your models here.
def ubicacion_imagen(instance, filename):
    return os.path.join('avatar', str(instance.id), filename)

class Administrador(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to=ubicacion_imagen, blank=True, null=True)
    empresa = models.CharField(max_length=75, blank=True, null=True)
    cargo = models.CharField(max_length=75, blank=True, null=True)
    telefono = models.CharField(max_length=75, blank=True, null=True)


class AdministradorToken(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE ,null=False)
    token = models.CharField(max_length=255, blank=False, null=False)


class CondicionFactibilidad(models.Model):
    descripcionCultivo = models.ForeignKey('DetalleCultivo', on_delete = models.CASCADE, null=True)
    nombre = models.CharField("Nombre de la condicion de factibilidad", max_length = 30 )
    contenido = models.CharField("Descripción", max_length = 300)

class TipoCultivo(models.Model):
    c = models.ForeignKey('Cultivo', on_delete=models.CASCADE, null=True)
    nombre = models.CharField("Tipo de cultivo", max_length = 20)
    descripcion = models.CharField("Descripcion", max_length = 400)

class Cultivo(models.Model):
    detalles = models.ForeignKey('DetalleCultivo', on_delete = models.CASCADE, null=True)
    tipoCultivo = models.ForeignKey('TipoCultivo', on_delete = models.CASCADE)
    nombre = models.CharField("Nombre del cultivo", max_length = 20)
    pesoPromedio = models.DecimalField(max_digits = 4, decimal_places = 2)
    nombreCientifico = models.CharField("Nombre Cientifico", max_length = 35)
    descripcion = models.CharField("Descripción", max_length = 350)

class DetalleCultivo(models.Model):
    cultivos = models.OneToOneField(Cultivo, on_delete = models.CASCADE)
    condicion = models.OneToOneField(CondicionFactibilidad, on_delete = models.CASCADE)
    descripcionDeFactibilidad = models.CharField("Descripción", max_length = 400)
