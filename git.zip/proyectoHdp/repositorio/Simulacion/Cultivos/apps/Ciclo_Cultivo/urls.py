from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name="index"),
    path('usuario/registrar', views.registrarUsuario.as_view(), name="registro"),
    path('usuario/listar', views.list_users, name="listar_user"),
    path('cultivos/gestionar', views.gestionar, name="gestionar_cultivos"),
    path('tipocultivo/listar', views.tipoCultivo.as_view(), name="listar_tipo"),
    path('tipocultivo/listar/<int:id>/', views.datosJSON, name="editar_tipo"),
    path('condicion/listar', views.condicion.as_view(), name="listar_condicion"),
    path('tipocultivo/eliminar/<int:id>/', views.delete, name="deleteType"),
    path('tipocultivo/listarJson', views.listarTipoCultivos, name='t_list'),
    path('condicion/listar/<int:id>/', views.condicionJSON, name="editar_c"),
    path('condicion/eliminar/<int:id>/', views.deleteC, name="deleteC"),
    path('cultivos/listar', views.gestionCultivo.as_view(),name='lista_cultivos'),
    path('cultivo/listar/<int:id>/', views.ajaxCultivo, name="editar_cultivo"),
    path('cultivos/editar/<int:id>/', views.editarC, name="edit_C"),
    path('cultivos/eliminar/<int:id>/', views.eliminarC, name="delete_C"),
]
