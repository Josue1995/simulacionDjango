from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.contrib.auth.models import User
from apps.Ciclo_Cultivo.models import TipoCultivo, Cultivo, CondicionFactibilidad, Administrador, DetalleCultivo
from django.views.generic.edit import CreateView
from django.views.generic.base import TemplateView
from django.urls import reverse_lazy
from apps.Ciclo_Cultivo.forms import RegistroForm
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist

# Vista principal: Pagina de presentacion
def index(request):
    if request.method == 'GET':
        return render(request, 'pagina_principal/index.html', {})
    else:
        response = HttpResponse()
        return response.write("<p>No se encontro la pagina</p>")

class registrarA(TemplateView):
    template_name = "administrador/usuarios/registrarAdministrador.html"

    def get(self, request):
        return render(request, template_name=self.template_name)

    def post(self ,request):
        userText = request.POST['username']
        empresa = request.POST['empresa']
        cargo = request.POST['cargo']
        telefono = request.POST['telefono']
        try:
            user = User.objects.get(username=userText)
            if user:
                admin = Administrador.objects.create(user=user)
                admin.empresa = empresa
                admin.cargo = cargo
                admin.telefono = telefono
                admin.save()
                return HttpResponseRedirect('login')
            else:
                messages.error(request, "No existe el usuario que digito")
                return render(request, self.template_name)

        except ObjectDoesNotExist:
            messages.error(request, "No existe el usuario que digito")
            return render(request, self.template_name)



#Vista basada en clase para registrar usuarios
class registrarUsuario(CreateView):
    model = User
    template_name = 'administrador/usuarios/registrar.html'
    form_class = RegistroForm
    success_url = reverse_lazy('listar_user')


#funcion para listar usuarios creados
def list_users(request):
    usuarios = User.objects.all()
    if usuarios :
        return render(request, 'administrador/usuarios/listar_usuarios.html', {'users':usuarios})
    else:
        response = HttpResponse()
        return response.write('<p>No se encontro su petición</p>')

#Vista para ingresar al area de simulaciones
class simulacion(TemplateView):
    template_name = "simulacion/simular.html"

    def get(self, request):
        cultivos = Cultivo.objects.all()
        return render(request, 'simulacion/simular.html', {'c':cultivos})

    def post(self, request):
        if request.method == 'POST':
            pass

#Vista para ingresar al log in de la app
def log_in(request):
    if request.user.is_authenticated:
        return redirect('sesion')
    else:
        return render(request, 'pagina_principal/login.html', {})

#Vista para iniciar sesion
def iniciarSesion(request):
    if request.user.is_authenticated:
        return render(request, 'administrador/usuarios/inicio.html', {'nombre':request.user.first_name})
    elif request.method == 'POST':
        username = request.POST['usuario']
        passwd = request.POST['contrasenia']
        try:
            u = User.objects.get(username=username)
            admin = Administrador.objects.get(user_id=u.id)
            if admin:
                sesion = authenticate(request, username = username , password  = passwd)
                if sesion is not None:
                    login(request, sesion)
                    return render(request, 'administrador/usuarios/inicio.html', {'nombre':request.user.first_name})
        except ObjectDoesNotExist:
            messages.error(request, "<strong>Su cuenta aun no esta registrada</strong>")
            return HttpResponseRedirect('login')
    else :
        return HttpResponse("La página que está solicitando no se encuentra disponible")

#vista para gestionar todo sobre gestion_cultivos
def gestionar(request):
    if request.method == 'GET':
        return render(request, 'cultivos/gestion.html', {})
    else:
        response = HttpResponse();
        return response.write("No se encuentra la pagina solicitada")

#Clase que se encarga de listar, crear y editar tipo de cultivos
class tipoCultivo(TemplateView):
    template_name = "tipocultivo/listar_tipo.html"

    def get(self, request):
        tipo= TipoCultivo.objects.all()
        context = {'tipoc' : tipo}
        if tipo:
            return render(request, self.template_name, context)
        else:
            messages.error(request, "<strong>No hay registros</strong>")
            return render(request, self.template_name, {})

    def post(self, request):
        nom = request.POST['nombre']
        des = request.POST['descripcion']
        tip, created = TipoCultivo.objects.get_or_create(nombre=nom)
        if created:
            tip.nombre = nom
            tip.descripcion = des
            tip.save()
            context = TipoCultivo.objects.all()
            return render(request, self.template_name, {'tipoc':context})
        else:
            TipoCultivo.objects.filter(nombre=nom).update(descripcion=des)
            context = TipoCultivo.objects.all()
            return render(request, self.template_name, {'tipoc':context})

#Objeto json para editar un cultivo
def datosJSON(request, id):
    tipo = TipoCultivo.objects.get(id=id)
    json = {
            'nombre':tipo.nombre,
            'descripcion':tipo.descripcion,
    }
    return JsonResponse(json)

#objeto json para eliminar un cultivo
def delete(request, id):
    TipoCultivo.objects.get(id=id).delete()
    mensaje = "Objeto eliminado"
    json = {
        'respuesta':mensaje
    }
    return JsonResponse(json)

#Clase condicion de factibilidad se encarga de crear, listar y editar Condiciones
class condicion(TemplateView):
    template_name = "condicionesF/cf.html"

    def get(self, request):
        c = CondicionFactibilidad.objects.all()
        if c:
            return render(request, self.template_name, {'condicion':c})
        else:
            messages.info(request, "<strong>No hay datos que listar</strong>")
            return render(request, self.template_name, {'condicion':c})

    def post(self, request):
        nom = request.POST['nombre']
        con = request.POST['contenido']
        c2, created = CondicionFactibilidad.objects.get_or_create(nombre=nom)
        if created:
            c2.nombre = nom
            c2.contenido = con
            c2.save()
            c = CondicionFactibilidad.objects.all()
            return render(request, self.template_name, {'condicion':c})
        else:
            CondicionFactibilidad.objects.filter(nombre=nom).update(contenido=con)
            context = CondicionFactibilidad.objects.all()
            return render(request, self.template_name, {'condicion':context})
#vista basada en funcion para retornar datos en json y editar una condicion
def condicionJSON(request, id):
    c = CondicionFactibilidad.objects.get(id = id)
    json = {
            'nombre': c.nombre,
            'contenido': c.contenido,
    }
    return JsonResponse(json)

#Eliminar una condiciones
def deleteC(request, id):
    CondicionFactibilidad.objects.get(id=id).delete()
    mensaje = "Objeto eliminado"
    json = {
        'respuesta':mensaje
    }
    return JsonResponse(json)


#editar perfil del usuario
class editarPerfil(TemplateView):
    template_name = "administrador/usuarios/perfil.html"

    def get(self, request):
        u = User.objects.get(id=request.user.id)
        a = Administrador.objects.get(user_id = u.id)
        if a:
            return render(request, self.template_name, {'a':a})
        else:
            messages.error(request, "<strong>Usuario no encontrado</strong>")
            return HttpResponseRedirect('sesion')

    def post(self, request):
        nombres = request.POST['first_name']
        apellidos = request.POST['last_name']
        email = request.POST['email']
        telefono = request.POST['telefono']
        cargo = request.POST['cargo']
        empresa = request.POST['empresa']
        user = User.objects.get(id=request.user.id)
        admin = Administrador.objects.get(user_id=user.id)
        if user is not None:
            user.first_name = nombres
            user.last_name = apellidos
            user.email = email
            admin.telefono = telefono
            admin.cargo = cargo
            admin.empresa = empresa
            user.save()
            admin.save()
            return HttpResponseRedirect('inicio')
        else:
            messages.error(request, "<b>No se encontró ningún usuario</b>")
            return HttpResponseRedirect('sesion')

class gestionCultivo(TemplateView):
    template_name = "cultivos/listar_cultivos.html"

    def get(self, request):
        cultivos = Cultivo.objects.order_by('id')
        if cultivos:
            return render(request, self.template_name, {'cultivos':cultivos})
        else:
            messages.info(request, "No hay datos que mostrar")
            return render(request, self.template_name,{})

    def post(self, request):
        n = request.POST['nombre']
        p = request.POST['peso']
        nc = request.POST['nombreCientifico']
        d = request.POST['descripcion']
        tc = request.POST['tipo']

        try:
            t = TipoCultivo.objects.get(nombre=tc)
            cultivo = Cultivo.objects.create(tipoCultivo=t, nombre=n, pesoPromedio=p, nombreCientifico=nc, descripcion=d)
            cultivo.save()
            cAll = Cultivo.objects.all()
            return render(request, self.template_name, {'cultivos':cAll})

        except ObjectDoesNotExist:
            messages.error(request, "No es posible crear el cultivo, no hay tipos de cultivo para su creación")
            cultivos = Cultivo.objects.all()
            return render(request, self.template_name,{'cultivos':cultivos})

def listarTipoCultivos(request):
    tipos = TipoCultivo.objects.values()
    lista = list(tipos)
    return JsonResponse(lista, safe=False)

def ajaxCultivo(request, id):
    cultivo = Cultivo.objects.get(id=id)
    context = {
        'id':cultivo.id,
        'nombre':cultivo.nombre,
        'peso':cultivo.pesoPromedio,
        'nombreC':cultivo.nombreCientifico,
        'descripcion':cultivo.descripcion,
        'nombreT':cultivo.tipoCultivo.nombre
    }
    return JsonResponse(context)

def editarC(request, id):
    if request.is_ajax():
        nombre = request.POST.get('nombre')
        nombreC = request.POST.get('cientifico')
        descripcion = request.POST.get('descripcion')
        peso = request.POST.get('peso')
        cultivo = Cultivo.objects.filter(id=id).update(nombre=nombre, pesoPromedio = peso, nombreCientifico= nombreC, descripcion =descripcion)

        return JsonResponse({"answer":"exito"})
    else:
        messages.error(request, "No existe el cultivo que desea editar")
        return HttpResponseRedirect('cultivos/listar')

def eliminarC(request, id):
    if request.method == 'POST':
        if request.is_ajax():
            cultivo = Cultivo.objects.filter(id=id)
            cultivo.delete()
            return JsonResponse({"answer":"eliminado"})
    else:
        messages.error(request, "No se pudo eliminar")
        return HttpResponseRedirect('cultivos/listar')
