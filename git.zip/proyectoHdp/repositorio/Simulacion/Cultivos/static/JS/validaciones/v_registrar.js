var inputs = document.getElementsByTagName('input');
var campo = null;
var passwd1 = null;
var passwd2 = null;
var b = null;

function validar() {
  for (var i = 1; i < inputs.length-4; i++) {
    inputs[i].addEventListener('blur', function (event) {
      campo = event.target.value;
      for (var j = 0; j < campo.length; j++) {
        if(campo[j] == "!" || campo[j] == "(" || campo[j] == "@" || campo[j] == "|" || campo[j] == "°" || campo[j] == '"' || campo[j] == "¬" || campo[j] == "·" || campo[j] == "#" || campo[j] == "$" || campo[j] == "~" || campo[j] == "½" || campo[j] == "%" || campo[j] == "&" || campo[j] == "¬" || campo[j] == "/" || campo[j] == "{" || campo[j] == "}" || campo[j] == ")" || campo[j] == "]" || campo[j] == "[" || campo[j] == "?" || campo[j] == "¿" || campo[j] == "¡" || campo[j] == "`" || campo[j] == "*" || campo[j] == "+" || campo[j] == "-" || campo[j] == "/" || campo[j] == "." || campo[j] == "," || campo[j] == ";" || campo[j] == ":" || campo[j] == "-" || campo[j] == "_"){
          event.target.value = "";
          event.target.style.background = "pink";
          event.target.placeholder = "Ingrese letras nada mas";
        }
      }

    });
    inputs[i].addEventListener("focus", function (event) {
      event.target.value = "";
      event.target.style.background = "";
    })
  }
}

var correo = document.getElementById("email");
function validarEmail(){
  correo.addEventListener('blur', function (event) {
    campo = event.target.value;
    for (var j = 0; j < campo.length; j++) {
      if(campo[j] == "!" || campo[j] == "(" || campo[j] == "|" || campo[j] == "°" || campo[j] == '"' || campo[j] == "¬" || campo[j] == "·" || campo[j] == "#" || campo[j] == "$" || campo[j] == "~" || campo[j] == "½" || campo[j] == "%" || campo[j] == "&" || campo[j] == "¬" || campo[j] == "/" || campo[j] == "{" || campo[j] == "}" || campo[j] == ')' || campo[j] == "]" || campo[j] == "[" || campo[j] == "?" || campo[j] == "¿" || campo[j] == "¡" || campo[j] == "`" || campo[j] == "*" || campo[j] == "+" || campo[j] == "/" || campo[j] == "," || campo[j] == ";" || campo[j] == ":"){
        event.target.value = "";
        event.target.style.background = "pink";
        event.target.placeholder = "Ingrese letras nada mas";
      }
    }

  });
  correo.addEventListener("focus", function (event) {
    event.target.value = "";
    event.target.style.background = "";
  });
}

function password() {
  passwd1 = document.getElementById('password1').value;
  passwd2 = document.getElementById('password2').value;
  b = document.getElementById('warning');
  b.addEventListener('mouseenter', function (event) {
    if(passwd1.startsWith(passwd2.substring(0, passwd2.length))){
      event.target.disabled = false;

    } else {
      event.target.disabled = true;
    }

  });

}

validar();
validarEmail();
//password();
