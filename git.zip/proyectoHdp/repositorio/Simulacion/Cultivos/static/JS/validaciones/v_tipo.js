var inputs = document.getElementsByTagName('input');
var campo = null;

function validar() {
  for (var i = 1; i < inputs.length; i++) {
    inputs[i].addEventListener('blur', function (event) {
      campo = event.target.value;
      for (var j = 0; j < campo.length; j++) {
        if(campo[j] == "!" || campo[j] == "(" || campo[j] == "@" || campo[j] == "|" || campo[j] == "°" || campo[j] == '"' || campo[j] == "¬" || campo[j] == "·" || campo[j] == "#" || campo[j] == "$" || campo[j] == "~" || campo[j] == "½" || campo[j] == "%" || campo[j] == "&" || campo[j] == "¬" || campo[j] == "/" || campo[j] == "{" || campo[j] == "}" || campo[j] == ")" || campo[j] == "]" || campo[j] == "[" || campo[j] == "?" || campo[j] == "¿" || campo[j] == "¡" || campo[j] == "`" || campo[j] == "*" || campo[j] == "+" || campo[j] == "-" || campo[j] == "/" || campo[j] == "." || campo[j] == "," || campo[j] == ";" || campo[j] == ":" || campo[j] == "-" || campo[j] == "_"){
          event.target.value = "";
          event.target.style.background = "pink";
          event.target.placeholder = "Ingrese letras nada mas";
        }
      }

    });
    inputs[i].addEventListener("focus", function (event) {
      event.target.style.background = "";
    })
  }
}

validar();
